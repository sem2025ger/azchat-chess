// Principle-based Chess Coach Educational Mock Logic
// This system provides human-readable feedback based on general chess principles.

export interface CoachFeedback {
  type: string;
  reason: string;
  better: string;
  lesson: string;
  next: string;
}

const PRINCIPLES = [
  {
    type: "Development & Space",
    reason: "Your pieces are slightly cramped in the center, and the development of the kingside was a bit delayed.",
    better: "Prioritize getting the minor pieces out before launching an attack, especially in the opening phase.",
    lesson: "The center belongs to those who develop first.",
    next: "Training: Opening Principles & 10 Golden Rules of Development."
  },
  {
    type: "King Safety",
    reason: "The king was left in the center for too long while the position started to open up.",
    better: "Castle early to bring the king to safety and connect your rooks behind the pawn wall.",
    lesson: "A safe king is a happy king. Castling is often the most important defensive move.",
    next: "Training: Basic King Safety & Defensive Castling Patterns."
  },
  {
    type: "Piece Coordination",
    reason: "The rooks and queen were not working together effectively, leaving some key squares vulnerable.",
    better: "Try to create batteries or align pieces to double-attack a single strategic point.",
    lesson: "Chess is a team game; no piece can win the battle alone.",
    next: "Training: Major Piece Coordination & Battery Construction."
  },
  {
    type: "Pawn Structure",
    reason: "The creation of isolated d-pawn led to a long-term structural weakness that the opponent exploited.",
    better: "Be careful when pushing pawns that cannot be easily defended by other pawns later.",
    lesson: "Pawn structure is the skeleton of the position; if it breaks, the body fails.",
    next: "Training: Pawn Structures: The ISO and Haging Pawns."
  },
  {
    type: "Positional Advantage",
    reason: "The opponent's pieces occupy much better outposts, especially the knight on d5.",
    better: "Identify weak squares in the opponent's camp and try to place your pieces there permanently.",
    lesson: "Control the outpost, control the game.",
    next: "Training: Identifying Outposts & Improving Piece Placement."
  },
  {
    type: "Tactical Awareness",
    reason: "The game was lost due to a missed intermediate check (zwischenzug) during the exchange.",
    better: "Always look for forcing moves, even when it seems like a simple trade is happening.",
    lesson: "Tactics flow from a superior position, but they must be spotted to work.",
    next: "Training: Intermediate Moves & Counter-Attacks."
  }
];

export function getCoachFeedback(buttonId: string): CoachFeedback {
  // We can vary the feedback slightly based on the buttonId if we want, 
  // but for the mock, we can rotate or select based on ID.
  const index = Math.abs(buttonId.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0)) % PRINCIPLES.length;
  return PRINCIPLES[index];
}
