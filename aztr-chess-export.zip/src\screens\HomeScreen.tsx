import { Link } from 'react-router-dom';
import { Play, Grid, Trophy, MessageSquare, Activity, Users, Globe } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cx(...inputs: (string | undefined | null | false)[]) {
  return twMerge(clsx(inputs));
}

export default function HomeScreen() {
  const { t } = useLanguage();

  const stats = [
    { label: 'Oyunçular', value: '34,102', icon: Users, color: 'text-emerald-400' },
    { label: 'Aktiv matçlar', value: '12,450', icon: Activity, color: 'text-chess-active' },
    { label: 'Ölkələr', value: '3', icon: Globe, color: 'text-chess-gold' },
  ];

  return (
    <div className="flex flex-col h-full w-full p-6 md:p-12 overflow-y-auto custom-scrollbar items-center bg-[#161512] transition-all relative">

      {/* Dynamic Background Elements */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-chess-active/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-chess-gold/5 blur-[120px] rounded-full pointer-events-none" />

      {/* Hero Section */}
      <div className="w-full max-w-6xl mt-12 mb-20 text-center animate-fade-in-up relative z-10">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/5 border border-white/10 rounded-full mb-8 backdrop-blur-md shadow-xl">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_10px_#10b981]" />
          <span className="text-[0.6rem] font-black text-neutral-400 uppercase tracking-[0.25em]">Premium Chess Platform Demo</span>
        </div>

        <h1 className="text-5xl md:text-8xl font-black text-white mb-8 tracking-tighter leading-[1.1] transform-gpu">
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-chess-gold via-white to-white">AZTR</span> CHESS
        </h1>

        <p className="text-lg md:text-2xl text-neutral-400 font-medium max-w-3xl mx-auto mb-12 leading-relaxed px-4">
          {t('home.subtitle')}
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
          <Link to="/play" className="group flex items-center gap-4 px-10 py-5 bg-chess-active text-black font-black text-xl rounded-2xl shadow-[0_20px_50px_-15px_rgba(0,206,209,0.5)] hover:scale-105 hover:bg-cyan-300 transition-all active:scale-95">
            <Play fill="currentColor" size={24} className="group-hover:rotate-12 transition-transform" />
            {t('home.playNow')}
          </Link>
          <div className="flex items-center gap-8 px-8 py-4 bg-white/5 backdrop-blur-md rounded-2xl border border-white/5 shadow-2xl">
            {stats.map((s, i) => (
              <div key={i} className="flex flex-col items-center">
                <div className={cx("flex items-center gap-1.5 font-black text-lg", s.color)}>
                  <s.icon size={16} />
                  {s.value}
                </div>
                <span className="text-[0.55rem] font-black text-neutral-500 uppercase tracking-widest mt-0.5">{s.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Feature Navigation Cards */}
      <div className="w-full max-w-6xl grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 animate-fade-in-up delay-200 pb-20 relative z-10">
        <FeatureCard
          to="/play" icon={<Play size={36} />} title={t('home.cards.play.title')}
          desc={t('home.cards.play.desc')} color="text-chess-active"
          bg="bg-chess-active/10" border="border-chess-active/20"
          accent="bg-chess-active/40"
        />
        <FeatureCard
          to="/game" icon={<Grid size={36} />} title={t('home.cards.game.title')}
          desc={t('home.cards.game.desc')} color="text-chess-gold"
          bg="bg-chess-gold/10" border="border-chess-gold/20"
          accent="bg-chess-gold/40"
        />
        <FeatureCard
          to="/profile" icon={<Trophy size={36} />} title={t('home.cards.profile.title')}
          desc={t('home.cards.profile.desc')} color="text-purple-400"
          bg="bg-purple-500/10" border="border-purple-500/20"
          accent="bg-purple-500/40"
        />
        <FeatureCard
          to="/chat" icon={<MessageSquare size={36} />} title={t('home.cards.chat.title')}
          desc={t('home.cards.chat.desc')} color="text-emerald-400"
          bg="bg-emerald-500/10" border="border-emerald-500/20"
          accent="bg-emerald-500/40"
        />
      </div>

    </div>
  );
}

function FeatureCard({
  to, icon, title, desc, color, bg, border, accent
}: {
  to: string, icon: React.ReactNode, title: string, desc: string, color: string, bg: string, border: string, accent: string
}) {
  return (
    <Link to={to} className={cx(
      "group relative flex flex-col bg-neutral-900/40 backdrop-blur-2xl rounded-[2.5rem] p-8 border hover:bg-neutral-900/60 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.8)] overflow-hidden",
      border
    )}>
      {/* Card Decoration */}
      <div className={cx("absolute -top-4 -right-4 w-24 h-24 blur-3xl rounded-full opacity-20 group-hover:opacity-40 transition-opacity duration-700", accent)} />

      <div className={cx(
        "w-20 h-20 rounded-3xl flex items-center justify-center mb-8 shadow-2xl ring-1 transition-all duration-700 group-hover:scale-110 group-hover:rotate-3",
        bg, color, border.replace('border-', 'ring-')
      )}>
        {icon}
      </div>

      <div className="flex-1 space-y-4">
        <h3 className="text-2xl font-black text-white italic tracking-tight">{title}</h3>
        <p className="text-sm text-neutral-500 font-bold leading-relaxed line-clamp-3 group-hover:text-neutral-400 transition-colors">{desc}</p>
      </div>

      <div className="mt-8 flex items-center gap-2 text-[0.6rem] font-black text-neutral-600 uppercase tracking-widest group-hover:text-white transition-colors duration-500">
        <span>Kəşf et</span>
        <div className="h-px flex-1 bg-white/[0.05] group-hover:bg-white/[0.15] transition-colors" />
        <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
      </div>
    </Link>
  );
}

function ChevronRight({ size, className }: { size: number, className?: string }) {
  return (
    <svg
      width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
      className={className}
    >
      <path d="m9 18 6-6-6-6" />
    </svg>
  );
}
