import { useState, useEffect, useRef } from 'react';
import ChessBoardMock from '../components/ChessBoardMock';
import { Flag, Handshake, Send, ChevronLeft, ChevronRight, FastForward, Rewind, Info, Sparkles, Brain, Lightbulb, Zap, Shield, Target, HelpCircle, CheckCircle2, Languages, Compass, MessageSquare, History, Cpu } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { getCoachFeedback, type CoachFeedback } from '../utils/coachLogic';
import AIChatAssistant from '../components/AIChatAssistant';
import { translateMock } from '../utils/chatAssistantLogic';
import EvaluationBar from '../components/EvaluationBar';
import AnalysisPanel from '../components/AnalysisPanel';
import { StockfishEngine, type EngineResult } from '../utils/StockfishEngine';

function cx(...inputs: (string | undefined | null | false)[]) {
  return twMerge(clsx(inputs));
}

export default function GameScreen() {
  const { t, language } = useLanguage();
  const [activeTab, setActiveTab] = useState<'moves' | 'chat' | 'coach' | 'analysis'>('moves');
  const [timeLeft, setTimeLeft] = useState({ black: 522, white: 555 });
  const [coachFeedback, setCoachFeedback] = useState<CoachFeedback | null>(null);
  const [isThinking, setIsThinking] = useState(false);

  // Chat States
  const [chatInput, setChatInput] = useState("");
  const [showChatAssistant, setShowChatAssistant] = useState(false);
  const [translatedMessages, setTranslatedMessages] = useState<Record<number, string>>({});

  const initialGameMsgs = [
    { user: 'SiberianTiger', msg: 'gl hf!', time: '21:34', self: false },
    { user: 'You', msg: 'u2', time: '21:35', self: true },
  ];
  const [gameMsgs, setGameMsgs] = useState(initialGameMsgs);

  // Analysis States
  const engineRef = useRef<StockfishEngine | null>(null);
  const [engineResult, setEngineResult] = useState<EngineResult | null>(null);
  const [isAnalysing, setIsAnalysing] = useState(false);

  // Ticking timer effect
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => ({
        ...prev,
        white: prev.white > 0 ? prev.white - 1 : 0
      }));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Engine Initialization
  useEffect(() => {
    if (!engineRef.current) {
      engineRef.current = new StockfishEngine();
      engineRef.current.onResult((res) => {
        setEngineResult(res);
        setIsAnalysing(false);
      });
    }
  }, []);

  // Update analysis when tab changes to analysis
  useEffect(() => {
    if (activeTab === 'analysis' && engineRef.current) {
      setIsAnalysing(true);
      engineRef.current.analyze("startpos");
    } else if (engineRef.current) {
      engineRef.current.stop();
    }
  }, [activeTab]);

  const handleCoachAction = (actionId: string) => {
    setIsThinking(true);
    setCoachFeedback(null);
    setTimeout(() => {
      setCoachFeedback(getCoachFeedback(actionId));
      setIsThinking(false);
    }, 1200);
  };

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;
    const newMsg = {
      user: 'You',
      msg: chatInput,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      self: true
    };
    setGameMsgs([...gameMsgs, newMsg]);
    setChatInput("");
  };

  const handleTranslateGameMsg = (index: number, text: string) => {
    if (translatedMessages[index]) {
      const newMap = { ...translatedMessages };
      delete newMap[index];
      setTranslatedMessages(newMap);
    } else {
      setTranslatedMessages({
        ...translatedMessages,
        [index]: translateMock(text, language)
      });
    }
  };

  const handleAssistantSelect = (text: string) => {
    setChatInput(text);
    setShowChatAssistant(false);
  };

  const moves = [
    { n: 1, w: 'e4', b: 'e5', wTime: '9:59', bTime: '9:58' },
    { n: 2, w: 'Nf3', b: 'Nc6', wTime: '9:55', bTime: '9:54' },
    { n: 3, w: 'Bc4', b: 'Bc5', wTime: '9:48', bTime: '9:46' },
  ];

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const coachCategories = [
    {
      title: t('game.coach.category.strategy'),
      items: [
        { id: 'explainPos', label: t('game.coach.explainPos'), icon: Lightbulb, color: 'text-yellow-400' },
        { id: 'mainIdea', label: t('game.coach.mainIdea'), icon: Target, color: 'text-chess-active' },
        { id: 'posOrTac', label: t('game.coach.posOrTac'), icon: Brain, color: 'text-purple-400' },
        { id: 'attOrDef', label: t('game.coach.attOrDef'), icon: Sparkles, color: 'text-emerald-400' },
      ]
    },
    {
      title: t('game.coach.category.opening'),
      items: [
        { id: 'openingMistakes', label: t('game.coach.openingMistakes'), icon: Shield, color: 'text-blue-400' },
      ]
    },
    {
      title: t('game.coach.category.review'),
      items: [
        { id: 'improve', label: t('game.coach.improve'), icon: Zap, color: 'text-orange-400' },
        { id: 'whyLose', label: t('game.coach.whyLose'), icon: HelpCircle, color: 'text-red-400' },
        { id: 'mainLesson', label: t('game.coach.mainLesson'), icon: CheckCircle2, color: 'text-chess-gold' },
      ]
    }
  ];

  const tabs = [
    { id: 'moves', icon: History, label: t('game.tabs.moves') },
    { id: 'chat', icon: MessageSquare, label: t('game.tabs.chat') },
    { id: 'coach', icon: Brain, label: t('game.tabs.coach') },
    { id: 'analysis', icon: Cpu, label: t('game.tabs.analysis') },
  ] as const;

  return (
    <div className="flex flex-col lg:flex-row h-full w-full p-2 lg:p-8 gap-4 lg:gap-12 overflow-y-auto lg:overflow-hidden bg-[#161512] animate-fade-in relative transition-all">

      {/* Board Area - Central Focus */}
      <div className="flex-1 flex flex-col items-center justify-center relative min-h-max animate-scale-up group">

        <div className="w-full max-w-[70vh] lg:max-w-[80vh] 2xl:max-w-[90vh] flex flex-col gap-6 relative">

          <div className="flex justify-between items-center px-6 py-3 bg-black/40 rounded-3xl border border-white/5 shadow-2xl backdrop-blur-xl ring-1 ring-white/5">
            <div className="flex items-center gap-5">
              <div className="relative">
                <div className="w-14 h-14 bg-neutral-900 rounded-2xl flex items-center justify-center overflow-hidden shadow-2xl border border-white/10 ring-2 ring-black transform hover:scale-105 transition-transform">
                  <span className="text-3xl">🇷🇺</span>
                </div>
                <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 rounded-full border-[3px] border-[#161512] shadow-xl animate-pulse" />
              </div>
              <div className="hidden sm:block">
                <div className="flex items-center gap-2">
                  <span className="font-black text-white text-lg tracking-tight italic">SiberianTiger</span>
                  <span className="text-[0.6rem] font-black bg-white/10 text-neutral-400 px-2 py-0.5 rounded leading-none shadow-inner border border-white/5 uppercase tracking-widest">GM</span>
                </div>
                <div className="text-[0.7rem] text-neutral-500 font-bold uppercase tracking-[0.25em] mt-0.5 opacity-60">ELITE RATING: 2952</div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="bg-[#1a1a1a] px-8 py-3.5 rounded-2xl border-b-[6px] border-neutral-800 font-mono text-3xl font-black text-neutral-400 shadow-[0_15px_40px_rgba(0,0,0,0.6)] flex items-center justify-center min-w-[140px] ring-1 ring-white/5 transition-all">
                {formatTime(timeLeft.black)}
              </div>
            </div>
          </div>

          <div className="relative flex gap-6 md:gap-10 h-fit group/board">

            <div className={cx(
              "transition-all duration-1000 ease-in-out self-stretch h-full py-4",
              activeTab === 'analysis' ? "w-6 md:w-8 opacity-100 translate-x-0" : "w-0 opacity-0 overflow-hidden -translate-x-8 pointer-events-none"
            )}>
              <EvaluationBar
                score={engineResult?.evaluation || 0.0}
                isMate={!!engineResult?.mate}
                mateIn={engineResult?.mate}
                className="h-full rounded-2xl ring-2 ring-white/10 shadow-[0_0_30px_rgba(0,0,0,0.8)]"
              />
            </div>

            <div className="flex-1 relative rounded-[2rem] overflow-hidden shadow-[0_60px_120px_-30px_rgba(0,0,0,1)] border-b-[12px] border-black/60 ring-2 ring-white/5">
              <div className="absolute inset-0 bg-gradient-to-br from-white/[0.03] to-transparent pointer-events-none z-10" />
              <ChessBoardMock />
              <div className="absolute -inset-20 bg-chess-active/[0.04] blur-[100px] rounded-full opacity-0 group-hover/board:opacity-100 transition-opacity duration-1000 pointer-events-none" />
            </div>
          </div>

          <div className="flex justify-between items-center px-6 py-3 bg-black/40 rounded-3xl border border-white/5 shadow-2xl backdrop-blur-xl ring-1 ring-white/5">
            <div className="flex items-center gap-5">
              <div className="relative group/avatar">
                <div className="w-14 h-14 bg-neutral-900 rounded-2xl flex items-center justify-center overflow-hidden shadow-2xl border border-chess-gold/30 ring-2 ring-black group-hover/avatar:ring-chess-gold transition-all duration-500">
                  <span className="text-3xl">{language === 'az' ? '🇦🇿' : '🇹🇷'}</span>
                </div>
                <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 rounded-full border-[3px] border-[#161512] shadow-xl animate-pulse" />
              </div>
              <div className="hidden sm:block">
                <div className="flex items-center gap-2">
                  <span className="font-black text-white text-lg tracking-tight italic">QaraQaplan_99</span>
                  <span className="bg-chess-gold/20 text-chess-gold text-[0.6rem] px-2.5 py-1 rounded-full font-black uppercase ring-2 ring-chess-gold/40 shadow-[0_0_20px_rgba(223,176,98,0.35)] border border-chess-gold/20 tracking-widest">PRO TEAM</span>
                </div>
                <div className="text-[0.7rem] text-neutral-500 font-bold uppercase tracking-[0.25em] mt-0.5 opacity-60">MY RATING: 2850</div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="bg-neutral-950 px-8 py-3.5 rounded-2xl border-b-[6px] border-chess-active font-mono text-3xl font-black text-white shadow-[0_15px_50px_-5px_rgba(0,206,209,0.5)] ring-1 ring-chess-active/40 flex items-center justify-center min-w-[140px] transition-all hover:translate-y-[-2px] active:translate-y-[1px]">
                {formatTime(timeLeft.white)}
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Professional Sidebar Sidebar Tabs */}
      <div className="w-full lg:w-[440px] shrink-0 flex flex-col bg-neutral-900/60 backdrop-blur-[60px] rounded-[3.5rem] border border-white/10 shadow-[0_80px_160px_-40px_rgba(0,0,0,1)] lg:h-[88vh] max-h-[1000px] animate-fade-in-right relative overflow-hidden border-b-[16px] border-black/80 ring-1 ring-white/5">

        {/* Premium Segmented Control Tab Navigation */}
        <nav className="p-3 bg-black/40 border-b border-white/[0.03] relative z-20 shrink-0">
          <div className="flex bg-neutral-900/80 p-1.5 rounded-[1.75rem] gap-1 relative overflow-hidden ring-1 ring-white/5">
            <div
              className={cx(
                "absolute top-1.5 bottom-1.5 bg-white/10 rounded-2xl transition-all duration-500 ease-in-out shadow-2xl ring-1 ring-white/10",
                activeTab === 'moves' ? "left-1.5 w-[calc(25%-6px)]" :
                  activeTab === 'chat' ? "left-[calc(25%+1.5px)] w-[calc(25%-6px)]" :
                    activeTab === 'coach' ? "left-[calc(50%+1.5px)] w-[calc(25%-6px)]" :
                      "left-[calc(75%+1.5px)] w-[calc(25%-6px)]"
              )}
            />
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={cx(
                  "flex-1 py-4.5 px-1 rounded-2xl text-[0.6rem] font-black uppercase tracking-[0.2em] transition-all duration-300 flex flex-col items-center gap-1.5 relative z-10",
                  activeTab === tab.id ? "text-white" : "text-neutral-600 hover:text-neutral-400"
                )}
              >
                <tab.icon size={18} className={cx("transition-transform group-hover:scale-110", activeTab === tab.id ? "text-chess-active" : "text-neutral-700")} />
                <span className="truncate w-full text-center scale-95 opacity-80">{tab.label}</span>
              </button>
            ))}
          </div>
        </nav>

        <div className="flex-1 overflow-hidden flex flex-col bg-black/[0.05]">

          {activeTab === 'moves' && (
            <div className="flex-1 flex flex-col overflow-hidden animate-fade-in bg-black/[0.1]">
              <div className="flex-1 overflow-y-auto custom-scrollbar">
                <table className="w-full text-left border-collapse">
                  <thead className="sticky top-0 bg-neutral-950/95 backdrop-blur-3xl z-20 border-b border-white/[0.03]">
                    <tr className="text-[0.65rem] font-black text-neutral-600 uppercase tracking-[0.3em]">
                      <th className="py-5 px-5 text-center w-16 border-r border-white/[0.03]">#</th>
                      <th className="py-5 px-8">{t('game.white')}</th>
                      <th className="py-5 px-8">{t('game.black')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[0.03]">
                    {moves.map((move, i) => (
                      <tr key={i} className="hover:bg-white/[0.04] transition-all group cursor-pointer text-sm font-black relative group/row">
                        <td className="py-4 px-2 text-neutral-600 bg-black/30 text-center border-r border-white/[0.03] text-[0.75rem] font-mono tracking-tighter italic">{move.n}.</td>
                        <td className="py-4 px-8 relative">
                          <div className="flex justify-between items-center group-hover/row:text-chess-gold transition-colors">
                            <span className="text-neutral-300 group-hover/row:scale-105 transition-transform origin-left">{move.w}</span>
                            <span className="text-[0.7rem] text-neutral-700 font-mono italic opacity-40 group-hover:opacity-80">{move.wTime}</span>
                          </div>
                        </td>
                        <td className="py-4 px-8 relative">
                          <div className="flex justify-between items-center group-hover/row:text-chess-active transition-colors">
                            <span className="text-neutral-300 group-hover/row:scale-105 transition-transform origin-left">{move.b}</span>
                            <span className="text-[0.7rem] text-neutral-700 font-mono italic opacity-40 group-hover:opacity-80">{move.bTime}</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="h-24 bg-black/50 border-t border-white/[0.03] flex items-center justify-center gap-14 px-10 shrink-0 shadow-[0_-20px_40px_rgba(0,0,0,0.5)]">
                <button className="text-neutral-500 hover:text-white p-4 hover:bg-white/5 rounded-3xl transition-all shadow-xl active:scale-90 group"><Rewind size={24} className="group-hover:scale-110 transition-transform" /></button>
                <button className="text-neutral-500 hover:text-white p-4 hover:bg-white/5 rounded-3xl transition-all shadow-xl active:scale-90 group"><ChevronLeft size={32} className="group-hover:translate-x-1 transition-transform" /></button>
                <button className="text-neutral-500 hover:text-white p-4 hover:bg-white/5 rounded-3xl transition-all shadow-xl active:scale-90 group"><ChevronRight size={32} className="group-hover:translate-x-1 transition-transform" /></button>
                <button className="text-neutral-500 hover:text-white p-4 hover:bg-white/5 rounded-3xl transition-all shadow-xl active:scale-90 group"><FastForward size={24} className="group-hover:scale-110 transition-transform" /></button>
              </div>
            </div>
          )}

          {activeTab === 'chat' && (
            <div className="flex-1 flex flex-col p-10 gap-10 overflow-hidden animate-fade-in relative bg-black/[0.15]">
              <div className="flex-1 overflow-y-auto custom-scrollbar pr-3 space-y-8">
                {gameMsgs.map((m, i) => (
                  <div key={i} className={cx("flex flex-col gap-2 group animate-fade-in-up", m.self ? "items-end" : "items-start")}>
                    <div className="flex items-center gap-4 px-3">
                      {!m.self && (
                        <button onClick={() => handleTranslateGameMsg(i, m.msg)} className="p-2.5 opacity-0 group-hover:opacity-100 transition-all text-neutral-600 hover:text-chess-active bg-white/5 rounded-2xl border border-white/5 backdrop-blur-2xl shadow-xl ring-1 ring-white/5">
                          <Languages size={14} />
                        </button>
                      )}
                      <span className="text-[0.7rem] font-black text-neutral-600 uppercase tracking-[0.3em] italic group-hover:text-neutral-500 transition-colors">{m.user}</span>
                    </div>
                    <div className={cx(
                      "px-8 py-4.5 rounded-[2.5rem] text-sm font-black border max-w-[95%] shadow-[0_25px_60px_rgba(0,0,0,0.8)] transition-all relative overflow-hidden leading-relaxed",
                      m.self ? "bg-chess-gold/10 text-chess-gold border-chess-gold/30 rounded-tr-none ring-1 ring-chess-gold/20" : "bg-white/5 text-neutral-100 border-white/10 rounded-tl-none backdrop-blur-3xl ring-1 ring-white/5"
                    )}>
                      {translatedMessages[i] || m.msg}
                    </div>
                  </div>
                ))}
              </div>
              <div className="relative mt-auto pt-8 border-t border-white/10">
                {showChatAssistant && <AIChatAssistant currentInput={chatInput} onSelect={handleAssistantSelect} onClose={() => setShowChatAssistant(false)} />}
                <div className="relative group/input">
                  <div className="absolute -inset-1 bg-gradient-to-r from-chess-gold/20 to-chess-active/20 blur opacity-0 group-hover/input:opacity-100 transition-opacity rounded-[2rem] pointer-events-none" />
                  <input value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSendMessage()} placeholder={t('game.chat.placeholder')} className="relative w-full bg-black/80 border border-white/10 rounded-[2rem] py-6 pl-8 pr-28 text-sm text-white placeholder-neutral-800 font-black focus:outline-none focus:border-chess-active transition-all shadow-[inset_0_5px_15px_rgba(0,0,0,0.6)] ring-1 ring-white/[0.03] tracking-tight" />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-3">
                    <button onClick={() => setShowChatAssistant(!showChatAssistant)} className={cx("p-3 rounded-2xl transition-all shadow-2xl active:scale-95 group/sparkle", showChatAssistant ? "bg-chess-active text-white scale-110" : "text-neutral-600 hover:text-chess-active hover:bg-chess-active/10")}>
                      <Sparkles size={24} className="group-hover/sparkle:rotate-12 transition-transform" />
                    </button>
                    <button onClick={handleSendMessage} className="p-3 text-neutral-600 hover:text-white bg-white/5 rounded-2xl hover:bg-white/10 shadow-2xl group/send active:scale-90 ring-1 ring-white/10">
                      <Send size={24} className="group-hover/send:translate-x-1 group-hover/send:-translate-y-1 transition-transform" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'coach' && (
            <div className="flex-1 flex flex-col p-8 gap-8 overflow-y-auto custom-scrollbar animate-fade-in bg-black/[0.15]">

              {/* Premium Coach Status Card */}
              <div className="bg-gradient-to-br from-chess-gold/15 to-transparent p-7 rounded-[3rem] border border-chess-gold/30 shadow-[0_25px_50px_rgba(223,176,98,0.15)] flex items-center gap-6 group hover:translate-y-[-2px] transition-all relative overflow-hidden ring-1 ring-chess-gold/20 shrink-0">
                <div className="absolute top-0 right-0 w-32 h-32 bg-chess-gold/10 blur-[60px] rounded-full group-hover:bg-chess-gold/20 transition-all" />
                <div className="w-16 h-16 bg-chess-gold/20 rounded-[2.25rem] flex items-center justify-center text-chess-gold shadow-2xl border border-chess-gold/30 shrink-0 group-hover:scale-105 transition-transform duration-700">
                  <Brain size={32} className="animate-spin-slow" />
                </div>
                <div className="relative z-10 flex flex-col gap-1">
                  <h3 className="text-[0.7rem] font-black text-chess-gold uppercase tracking-[0.3em]">{t('game.coach.feedback.title')}</h3>
                  <p className="text-[0.75rem] font-bold text-white italic tracking-tight leading-tight uppercase">Educational Assistant</p>
                  <div className="flex items-center gap-2 mt-1 px-3 py-1 bg-emerald-500/10 rounded-full border border-emerald-500/20 w-fit">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_#10b981]" />
                    <span className="text-[0.55rem] font-black text-emerald-500 uppercase tracking-widest">{t('game.coach.status.ready')}</span>
                  </div>
                </div>
              </div>

              {/* Categorized Actions */}
              <div className="space-y-10 shrink-0">
                {coachCategories.map((cat, idx) => (
                  <div key={idx} className="space-y-4">
                    <div className="flex items-center justify-between px-2">
                      <span className="text-[0.6rem] font-black text-neutral-600 uppercase tracking-[0.3em]">{cat.title}</span>
                      <div className="h-px flex-1 mx-4 bg-white/[0.05]" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      {cat.items.map((btn) => (
                        <button
                          key={btn.id}
                          onClick={() => handleCoachAction(btn.id)}
                          disabled={isThinking}
                          className="flex flex-col items-center gap-4 p-5 bg-white/5 border border-white/5 rounded-[2.5rem] hover:bg-white/[0.08] hover:border-white/20 transition-all group/btn disabled:opacity-30 shadow-xl active:scale-95 ring-1 ring-white/5"
                        >
                          <div className={cx(btn.color, "p-3 bg-white/[0.03] rounded-2xl group-hover/btn:scale-110 transition-all duration-500 shadow-2xl ring-1 ring-white/10")}>
                            <btn.icon size={26} />
                          </div>
                          <span className="text-[0.6rem] font-black text-neutral-400 uppercase tracking-tighter text-center leading-tight px-1 group-hover/btn:text-white transition-colors">{btn.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Enhanced Feedback Display */}
              <div className="space-y-6 pt-10 border-t border-white/[0.05] relative min-h-[220px] pb-10 flex-1">
                {isThinking ? (
                  <div className="flex flex-col items-center justify-center py-20 gap-6 animate-pulse">
                    <div className="relative">
                      <Sparkles size={64} className="text-chess-gold animate-bounce opacity-10" />
                      <div className="absolute inset-0 flex items-center justify-center translate-y-2">
                        <Brain size={36} className="text-chess-gold/40 animate-spin-slow shadow-2xl" />
                      </div>
                    </div>
                    <div className="flex flex-col items-center gap-2">
                      <span className="text-[0.75rem] font-black text-neutral-500 uppercase tracking-[0.4em] italic">{t('game.coach.thinking')}</span>
                      <div className="w-32 h-1 bg-white/5 rounded-full overflow-hidden shadow-inner">
                        <div className="h-full bg-chess-gold w-1/4 animate-shimmer" />
                      </div>
                    </div>
                  </div>
                ) : coachFeedback ? (
                  <div className="space-y-10 animate-fade-in-up">
                    <div className="flex items-center gap-4 pb-4 border-b border-white/[0.05] relative">
                      <div className="w-2.5 h-10 bg-chess-gold rounded-full shadow-[0_0_20px_#dfb062] z-10" />
                      <div className="absolute left-0 top-0 bottom-0 w-2.5 h-10 bg-chess-gold/30 blur-lg rounded-full" />
                      <h4 className="font-black text-white text-xl italic uppercase tracking-tighter shadow-sm">{t('game.coach.feedback.title')} Result</h4>
                    </div>
                    <div className="space-y-8">
                      {[
                        { label: t('game.coach.feedback.type'), value: coachFeedback.type, color: 'text-chess-active', icon: Info },
                        { label: t('game.coach.feedback.reason'), value: coachFeedback.reason, color: 'text-neutral-100', icon: Target },
                        { label: t('game.coach.feedback.better'), value: coachFeedback.better, color: 'text-emerald-400', icon: Compass },
                        { label: t('game.coach.feedback.lesson'), value: coachFeedback.lesson, color: 'text-chess-gold', icon: Brain },
                        { label: t('game.coach.feedback.next'), value: coachFeedback.next, color: 'text-neutral-500 italic', icon: History },
                      ].map((item, idx) => (
                        <div key={idx} className="space-y-3 px-2 group/item flex gap-5">
                          <div className="p-3 bg-white/5 rounded-2xl h-fit border border-white/5 group-hover/item:border-white/20 transition-all">
                            <item.icon size={18} className={cx(item.color, "opacity-70")} />
                          </div>
                          <div className="flex-1 space-y-1">
                            <span className="text-[0.6rem] font-black text-neutral-600 uppercase tracking-[0.3em] group-hover/item:text-neutral-400 transition-colors uppercase">{item.label}</span>
                            <div className={cx("text-sm font-black leading-relaxed tracking-tight transition-all", item.color)}>{item.value}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center p-12 gap-8 opacity-10 group cursor-default h-full border-2 border-white/5 border-dashed rounded-[3rem]">
                    <Brain size={80} className="group-hover:scale-110 transition-transform duration-1000 group-hover:rotate-6 shadow-2xl" />
                    <div className="flex flex-col items-center gap-2">
                      <span className="text-[0.7rem] font-black uppercase tracking-[0.4em] italic shadow-inner">Intelligence Module Standby</span>
                      <span className="text-[0.6rem] font-bold text-neutral-600 uppercase tracking-widest">Select a strategic consultant action</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'analysis' && (
            <AnalysisPanel
              score={engineResult?.evaluation || 0.0}
              bestMove={engineResult?.bestMove}
              depth={engineResult?.depth || 0}
              loading={isAnalysing}
              candidates={engineResult?.continuation ? [engineResult.continuation] : undefined}
              noMoves={moves.length === 0}
              error={!engineRef.current?.isReady()}
            />
          )}

        </div>

        {/* Professional Game Control Center */}
        <div className="p-10 bg-black/60 border-t border-white/10 grid grid-cols-2 gap-8 shrink-0 shadow-[0_-40px_80px_-20px_rgba(0,0,0,0.8)] relative z-30 ring-1 ring-white/5 backdrop-blur-3xl">
          <button className="flex flex-col items-center justify-center gap-3 py-6 rounded-[2.5rem] bg-white/5 hover:bg-red-500/10 text-neutral-500 hover:text-red-400 font-black text-[0.75rem] uppercase tracking-[0.2em] border border-white/5 group shadow-2xl transition-all active:scale-95 hover:border-red-500/20 ring-1 ring-white/5">
            <Flag size={22} className="group-hover:rotate-[15deg] group-hover:scale-110 transition-all duration-500" />
            {t('game.resign')}
          </button>
          <button className="flex flex-col items-center justify-center gap-3 py-6 rounded-[2.5rem] bg-white/5 hover:bg-white/10 text-neutral-500 hover:text-white font-black text-[0.75rem] uppercase tracking-[0.2em] border border-white/5 shadow-2xl transition-all active:scale-95 group hover:border-white/20 ring-1 ring-white/5">
            <Handshake size={26} strokeWidth={2.5} className="group-hover:scale-110 transition-all duration-500" />
            {t('game.draw')}
          </button>
        </div>

      </div>
    </div>
  );
}
