import { Target, Trophy, Swords, Zap, Activity, Calendar, MapPin, ChevronRight, Award } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cx(...inputs: (string | undefined | null | false)[]) {
  return twMerge(clsx(inputs));
}

export default function ProfileScreen() {
  const { t } = useLanguage();

  const stats = [
    { label: 'Blitz', value: '1850', icon: Zap, color: 'text-amber-400', bg: 'bg-amber-400/5', border: 'border-amber-400/20' },
    { label: 'Rapid', value: '1920', icon: Target, color: 'text-chess-active', bg: 'bg-chess-active/5', border: 'border-chess-active/20' },
    { label: 'Bullet', value: '1740', icon: Swords, color: 'text-rose-400', bg: 'bg-rose-400/5', border: 'border-rose-400/20' },
  ];

  const recentGames = [
    { result: 'win', opp: 'IstanbulKing', r1: '1850', r2: '1845', type: 'Blitz 3+2', date: '2 hrs ago', flag: '🇹🇷' },
    { result: 'loss', opp: 'SiberianTiger', r1: '1840', r2: '1952', type: 'Rapid 10+0', date: 'Yesterday', flag: '🇷🇺' },
    { result: 'draw', opp: 'KasparovFan', r1: '1842', r2: '1842', type: 'Blitz 3+0', date: 'Yesterday', flag: '🇦🇿' },
  ];

  return (
    <div className="max-w-6xl mx-auto p-6 md:p-12 overflow-y-auto custom-scrollbar bg-[#161512]">

      {/* Profile Identity - High Fidelity */}
      <div className="bg-neutral-900/40 backdrop-blur-3xl border border-white/5 rounded-[3.5rem] p-8 md:p-14 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.9)] animate-fade-in-up flex flex-col md:flex-row items-center gap-12 mb-12 relative overflow-hidden ring-1 ring-white/5 group">

        {/* Glow behind profile */}
        <div className="absolute -left-20 -top-20 w-[600px] h-[600px] bg-chess-gold/5 blur-[120px] pointer-events-none group-hover:bg-chess-gold/10 transition-colors duration-1000" />
        <div className="absolute right-0 bottom-0 w-96 h-96 bg-chess-active/5 blur-[120px] pointer-events-none" />

        <div className="relative z-10 shrink-0">
          <div className="w-44 h-44 bg-neutral-800 rounded-[2.5rem] flex items-center justify-center overflow-hidden shadow-[0_30px_60px_-10px_rgba(0,0,0,0.8)] border-[3px] border-chess-gold/40 relative group/avatar transform hover:scale-105 transition-transform duration-700 ring-4 ring-black/50">
            <span className="text-8xl group-hover/avatar:scale-110 transition-transform">🇦🇿</span>
          </div>
          <div className="absolute -bottom-4 -right-4 bg-emerald-500 text-black p-3.5 rounded-2xl shadow-2xl border-4 border-[#161512] animate-bounce z-20">
            <Zap size={20} fill="currentColor" />
          </div>
        </div>

        <div className="flex-1 text-center md:text-left relative z-10 space-y-8">
          <div>
            <div className="flex items-center justify-center md:justify-start gap-4 mb-4">
              <h1 className="text-4xl md:text-6xl font-black text-white italic tracking-tighter transform-gpu skew-x-[-1deg]">QaraQaplan_99</h1>
              <span className="bg-chess-gold font-black text-black text-[0.65rem] px-3.5 py-1.5 rounded-xl uppercase tracking-widest shadow-lg shadow-chess-gold/20 animate-pulse">PRO</span>
            </div>
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-6 text-neutral-500 font-black text-[0.7rem] uppercase tracking-[0.25em]">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 border border-white/5 rounded-full backdrop-blur-md">
                <MapPin size={14} className="text-chess-active" /> Baku, Azerbaijan
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 border border-white/5 rounded-full backdrop-blur-md">
                <Calendar size={14} className="text-chess-gold" /> {t('profile.memberSince')} 2024
              </div>
            </div>
          </div>

          {/* Rating Dashboard Section */}
          <div className="grid grid-cols-3 gap-6 max-w-xl mx-auto md:mx-0">
            {stats.map((s, i) => (
              <div key={i} className={cx(
                "flex flex-col p-5 rounded-[2rem] border transition-all duration-500 hover:scale-[1.05] shadow-2xl group/stat ring-1",
                s.bg, s.border, s.border.replace('border-', 'ring-')
              )}>
                <div className={cx("flex items-center gap-2 text-[0.6rem] font-black uppercase tracking-[0.2em] mb-2", s.color)}>
                  <s.icon size={14} /> {s.label}
                </div>
                <span className="text-3xl font-black text-white italic tracking-tighter tabular-nums group-hover/stat:translate-x-1 transition-transform">{s.value}</span>
                <div className="mt-3 flex items-center gap-1.5">
                  <div className="flex-1 h-0.5 bg-white/5 rounded-full overflow-hidden">
                    <div className={cx("h-full w-2/3 group-hover/stat:w-3/4 transition-all duration-1000", s.color.replace('text-', 'bg-'))} />
                  </div>
                  <span className={cx("text-[0.5rem] font-black uppercase", s.color)}>TOP 1%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">

        {/* Left Column: Stats & Performance */}
        <div className="space-y-12 animate-fade-in-up delay-200">
          <div className="bg-neutral-900/40 backdrop-blur-3xl border border-white/5 p-10 rounded-[3rem] shadow-[0_30px_60px_-10px_rgba(0,0,0,0.8)] ring-1 ring-white/5 space-y-10 group/perform">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-black text-white italic tracking-tighter uppercase flex items-center gap-4">
                <div className="p-3 bg-chess-active/10 rounded-2xl text-chess-active group-hover/perform:scale-110 transition-transform">
                  <Activity size={24} />
                </div>
                {t('profile.performance')}
              </h2>
              <div className="px-3 py-1 bg-white/5 rounded-full border border-white/5 text-[0.55rem] font-black text-neutral-500 tracking-widest uppercase">Global Rank: #452</div>
            </div>

            {/* Extended Win/Loss/Draw Dashboard */}
            <div className="space-y-6">
              <div className="flex justify-between text-[0.65rem] font-black uppercase tracking-widest text-neutral-500">
                <div className="flex flex-col gap-1">
                  <span className="text-emerald-400">{t('profile.wins')}</span>
                  <span className="text-2xl text-white">450</span>
                </div>
                <div className="flex flex-col gap-1 items-center">
                  <span className="text-neutral-500">{t('profile.draws')}</span>
                  <span className="text-2xl text-white text-center">120</span>
                </div>
                <div className="flex flex-col gap-1 items-end">
                  <span className="text-rose-400">{t('profile.losses')}</span>
                  <span className="text-2xl text-white">330</span>
                </div>
              </div>
              <div className="relative h-6 w-full bg-black/40 rounded-full overflow-hidden flex shadow-[inset_0_4px_10px_rgba(0,0,0,0.5)] border border-white/5 ring-1 ring-white/5">
                <div style={{ width: '50%' }} className="bg-emerald-500 relative group/win transition-all duration-700">
                  <div className="absolute inset-0 bg-white/20 opacity-0 group-hover/win:opacity-100" />
                </div>
                <div style={{ width: '13%' }} className="bg-neutral-500 relative group/draw transition-all duration-700">
                  <div className="absolute inset-0 bg-white/20 opacity-0 group-hover/draw:opacity-100" />
                </div>
                <div style={{ width: '37%' }} className="bg-rose-500 relative group/loss transition-all duration-700">
                  <div className="absolute inset-0 bg-white/20 opacity-0 group-hover/loss:opacity-100" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.05] to-transparent pointer-events-none" />
              </div>
              <div className="flex justify-center">
                <span className="text-[0.6rem] font-black text-neutral-600 uppercase tracking-widest italic flex items-center gap-2">Win Rate: 58.2% <div className="w-1 h-1 rounded-full bg-emerald-500 shadow-[0_0_5px_#10b981]" /></span>
              </div>
            </div>

            {/* Achievements/Trophies Showcase */}
            <div className="pt-10 border-t border-white/[0.03]">
              <h3 className="text-[0.65rem] font-black text-neutral-500 uppercase tracking-[0.3em] mb-6 flex items-center justify-between italic">
                {t('profile.recentTrophies')}
                <Award size={14} className="text-chess-gold" />
              </h3>
              <div className="flex gap-5">
                <div className="w-16 h-16 bg-gradient-to-br from-amber-500/20 to-transparent text-amber-500 rounded-[1.25rem] flex items-center justify-center border border-amber-500/30 shadow-[0_20px_40px_-5px_rgba(245,158,11,0.25)] ring-1 ring-amber-500/10 group-hover/perform:rotate-3 transition-all duration-700 scale-105">
                  <Trophy size={32} />
                </div>
                <div className="w-16 h-16 bg-white/5 text-neutral-500 rounded-[1.25rem] flex items-center justify-center border border-white/5 opacity-40 hover:opacity-100 transition-opacity">
                  <span className="font-black text-lg">#1</span>
                </div>
                <div className="w-16 h-16 bg-white/5 text-neutral-500 rounded-[1.25rem] flex items-center justify-center border border-white/5 opacity-40 hover:opacity-100 transition-opacity">
                  <span className="font-black text-lg">X10</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Historical Overview */}
        <div className="lg:col-span-2 space-y-8 animate-fade-in-up delay-300">
          <div className="flex items-center justify-between px-6">
            <h2 className="text-2xl font-black text-white italic tracking-tighter uppercase">{t('profile.recentGames')}</h2>
            <button className="text-[0.6rem] font-black text-chess-active uppercase tracking-widest hover:translate-x-1 transition-transform inline-flex items-center gap-2 group">
              View All History <ChevronRight size={14} className="group-hover:scale-110" />
            </button>
          </div>

          <div className="space-y-5">
            {recentGames.map((g, i) => (
              <div key={i} className="bg-neutral-900/40 backdrop-blur-3xl border border-white/5 p-6 rounded-[2.5rem] flex items-center justify-between hover:bg-neutral-900/60 transition-all cursor-pointer group/game shadow-xl ring-1 ring-white/5">
                <div className="flex items-center gap-8">
                  <div className={cx(
                    "w-16 h-16 rounded-[1.5rem] flex items-center justify-center font-black text-2xl shadow-2xl transition-all duration-500 group-hover/game:scale-110 group-hover/game:rotate-3 border border-current",
                    g.result === 'win' ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20 shadow-emerald-500/10" :
                      g.result === 'loss' ? "bg-rose-500/10 text-rose-400 border-rose-500/20 shadow-rose-500/10" : "bg-neutral-500/10 text-neutral-400 border-neutral-500/20"
                  )}>
                    {g.result === 'win' ? '1-0' : g.result === 'loss' ? '0-1' : '½-½'}
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-4">
                      <div className="w-8 h-8 rounded-lg bg-neutral-800 flex items-center justify-center text-lg border border-white/5 shadow-lg group-hover/game:translate-y-[-2px] transition-transform">{g.flag}</div>
                      <div className="font-black text-xl text-white tracking-tight italic group-hover/game:text-chess-active transition-colors flex items-center gap-3 underline decoration-white/5 group-hover/game:decoration-chess-active/30">
                        vs {g.opp}
                        <span className="text-[0.65rem] font-black text-neutral-500 bg-white/5 px-2.5 py-1 rounded-lg border border-white/5 normal-case tracking-normal italic">{g.r2} ELO</span>
                      </div>
                    </div>
                    <div className="text-[0.65rem] text-neutral-500 font-black uppercase tracking-widest mt-2 ml-12 flex items-center gap-3">
                      <span className="text-neutral-400">{g.type}</span>
                      <div className="w-1 h-1 rounded-full bg-neutral-800" />
                      <span className="opacity-60">{g.date}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3 pr-4">
                  <button className="flex items-center gap-2 px-6 py-3 bg-white/5 rounded-2xl text-[0.65rem] font-black text-neutral-500 uppercase tracking-widest border border-white/5 opacity-0 group-hover/game:opacity-100 transition-all hover:bg-chess-active/10 hover:text-chess-active hover:border-chess-active/20 group/rev">
                    {t('profile.review')}
                    <ChevronRight size={14} className="group-hover/rev:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
