import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { useThemeContext, type BoardTheme, type PieceTheme } from '../context/ThemeContext';

function cx(...inputs: (string | undefined | null | false)[]) {
  return twMerge(clsx(inputs));
}

export default function ChessBoardMock({ className, showCoordinates = true }: { className?: string, showCoordinates?: boolean }) {
  const { board, pieces, specialThemesEnabled } = useThemeContext();

  // Premium Board Color Palettes (Refined for High Contrast & Professional Look)
  const boardThemeClasses: Record<BoardTheme, { light: string, dark: string }> = {
    'Green': { light: 'bg-[#ebecd0]', dark: 'bg-[#779556]' },
    'Wood': { light: 'bg-[#debc8d]', dark: 'bg-[#8b4a1c]' },
    'Glass': { light: 'bg-white/20 backdrop-blur-sm', dark: 'bg-black/30 backdrop-blur-md' },
    'Brown': { light: 'bg-[#f0d9b5]', dark: 'bg-[#b58863]' },
    'Ice Sea': { light: 'bg-[#dee3e6]', dark: 'bg-[#8ca2ad]' },
    'Newspaper': { light: 'bg-[#ffffff]', dark: 'bg-[#d1d1d1]' },
    'Walnut': { light: 'bg-[#e3c16f]', dark: 'bg-[#b88b4a]' },
    'Sky': { light: 'bg-[#8ebad9]', dark: 'bg-[#4b7399]' },
    'Lolz': { light: 'bg-[#ffffcf]', dark: 'bg-[#ffcf62]' },
    'Stone': { light: 'bg-[#e0e0e0]', dark: 'bg-[#a0a0a0]' },
    'Warm Gold': { light: 'bg-[#f0d192]', dark: 'bg-[#a67c37]' },
    'Muted Gold': { light: 'bg-[#d9c5a0]', dark: 'bg-[#7d6b41]' },
    'Obsidian Gold': { light: 'bg-[#c4a671]', dark: 'bg-[#1a1a1a]' },
    'Charcoal Gold': { light: 'bg-[#b09b7c]', dark: 'bg-[#2b2b2b]' },
    'Champagne': { light: 'bg-[#f2e1c2]', dark: 'bg-[#c5ad85]' },
    'Luxury Beige': { light: 'bg-[#e5d5b3]', dark: 'bg-[#a68d60]' },
  };

  const activeBoardTheme = specialThemesEnabled ? (boardThemeClasses[board] || boardThemeClasses['Green']) : boardThemeClasses['Green'];

  const ranks = [8, 7, 6, 5, 4, 3, 2, 1];
  const files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

  return (
    <div className={cx(
      "w-full rounded-lg relative overflow-hidden transition-all duration-500",
      "p-2 md:p-3 bg-[#262421] border-[6px] border-[#312e2b] shadow-[0_40px_100px_-20px_rgba(0,0,0,0.8),inset_0_0_20px_rgba(0,0,0,0.4)]",
      className
    )}>
      {/* Wood Grain Texture Overlay for the frame */}
      <div className="absolute inset-0 opacity-[0.05] pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/wood-pattern.png')]" />

      <div className="aspect-square w-full rounded-sm overflow-hidden relative shadow-2xl border border-black/40">
        {/* Board Tiles */}
        <div className="grid grid-cols-8 grid-rows-8 w-full h-full relative z-0">
          {ranks.map((rank, rIndex) => (
            files.map((file, fIndex) => {
              const isDark = (rIndex + fIndex) % 2 !== 0;
              const tileBg = isDark ? activeBoardTheme.dark : activeBoardTheme.light;
              
              return (
                <div key={`${file}${rank}`} className={cx("w-full h-full relative group transition-colors duration-500", tileBg)}>
                  {/* Square Texture Overlay (Subtle grain) */}
                  <div className="absolute inset-0 opacity-[0.04] pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]" />
                  
                  {/* Coordinates (Chess.com Style) */}
                  {showCoordinates && fIndex === 0 && (
                    <span className={cx(
                      "absolute top-0.5 left-1 text-[0.55rem] md:text-[0.7rem] font-bold select-none",
                      isDark ? "text-white/50" : "text-black/40"
                    )}>
                      {rank}
                    </span>
                  )}
                  {showCoordinates && rIndex === 7 && (
                    <span className={cx(
                      "absolute bottom-0.5 right-1 text-[0.55rem] md:text-[0.7rem] font-bold select-none",
                      isDark ? "text-white/50" : "text-black/40"
                    )}>
                      {file}
                    </span>
                  )}
                </div>
              );
            })
          ))}
        </div>

        {/* Action Layer (Highlights) */}
        <div className="absolute inset-0 z-5 pointer-events-none">
           {/* Move Highlight (Previous Square) */}
           <div className="absolute w-[12.5%] h-[12.5%] bg-yellow-400/20" style={{ left: '37.5%', top: '75%' }} />
           {/* Move Highlight (Current Square) */}
           <div className="absolute w-[12.5%] h-[12.5%] bg-yellow-400/40 border-2 border-yellow-400/30" style={{ left: '37.5%', top: '50%' }} />
           
           {/* Legal Move Dots (Example) */}
           <div className="absolute w-[12.5%] h-[12.5%] flex items-center justify-center" style={{ left: '37.5%', top: '37.5%' }}>
              <div className="w-4 h-4 rounded-full bg-black/10 backdrop-blur-[2px]" />
           </div>
        </div>

        {/* Piece Layer */}
        <div className="absolute inset-0 z-10 pointer-events-none">
           <PiecesMock piecesTheme={pieces} />
        </div>
      </div>
    </div>
  );
}

// Higher Quality Piece Mappings using Reliable CDN Logic
function PiecesMock({ piecesTheme }: { piecesTheme: PieceTheme }) {
  const style = piecesTheme || 'neo';

  const pieces = [
    // Black Pieces
    { type: 'r', col: 'a', row: 8, color: 'b' }, { type: 'n', col: 'b', row: 8, color: 'b' }, { type: 'b', col: 'c', row: 8, color: 'b' }, { type: 'q', col: 'd', row: 8, color: 'b' }, { type: 'k', col: 'e', row: 8, color: 'b' }, { type: 'b', col: 'f', row: 8, color: 'b' }, { type: 'n', col: 'g', row: 8, color: 'b' }, { type: 'r', col: 'h', row: 8, color: 'b' },
    { type: 'p', col: 'a', row: 7, color: 'b' }, { type: 'p', col: 'b', row: 7, color: 'b' }, { type: 'p', col: 'c', row: 7, color: 'b' }, { type: 'p', col: 'd', row: 7, color: 'b' }, { type: 'p', col: 'e', row: 7, color: 'b' }, { type: 'p', col: 'f', row: 7, color: 'b' }, { type: 'p', col: 'g', row: 7, color: 'b' }, { type: 'p', col: 'h', row: 7, color: 'b' },
    
    // White Pieces
    { type: 'P', col: 'a', row: 2, color: 'w' }, { type: 'P', col: 'b', row: 2, color: 'w' }, { type: 'P', col: 'c', row: 2, color: 'w' }, { type: 'P', col: 'd', row: 2, color: 'w' }, { type: 'P', col: 'e', row: 2, color: 'w' }, { type: 'P', col: 'f', row: 2, color: 'w' }, { type: 'P', col: 'g', row: 2, color: 'w' }, { type: 'P', col: 'h', row: 2, color: 'w' },
    { type: 'R', col: 'a', row: 1, color: 'w' }, { type: 'N', col: 'b', row: 1, color: 'w' }, { type: 'B', col: 'c', row: 1, color: 'w' }, { type: 'Q', col: 'd', row: 1, color: 'w' }, { type: 'K', col: 'e', row: 1, color: 'w' }, { type: 'B', col: 'f', row: 1, color: 'w' }, { type: 'N', col: 'g', row: 1, color: 'w' }, { type: 'R', col: 'h', row: 1, color: 'w' },
  ];

  const getColIndex = (col: string) => col.charCodeAt(0) - 'a'.charCodeAt(0);
  
  return (
    <>
      {pieces.map((p, i) => {
        const x = getColIndex(p.col) * 12.5;
        const y = (8 - p.row) * 12.5;
        
        const side = p.color === 'w' ? 'w' : 'b';
        const typeChar = p.type.toUpperCase();
        const url = `https://lichess1.org/assets/piece/${style}/${side}${typeChar}.svg`;

        return (
          <img 
            key={i}
            src={url} 
            alt={p.type} 
            className="absolute w-[12.5%] h-[12.5%] transition-all duration-500"
            style={{ 
              left: `${x}%`, 
              top: `${y}%`, 
              filter: 'drop-shadow(0px 3px 4px rgba(0,0,0,0.5))' 
            }}
          />
        );
      })}
    </>
  );
}
