export type Language = 'ru' | 'az' | 'tr';

type TranslationDictionary = Record<string, Record<Language, string>>;

export const translations: TranslationDictionary = {
  // Navigation & Layout
  'nav.home': { ru: 'Главная', az: 'Ana Səhifə', tr: 'Ana Sayfa' },
  'nav.play': { ru: 'Играть', az: 'Oyna', tr: 'Oyna' },
  'nav.game': { ru: 'Игра', az: 'Oyun', tr: 'Oyun' },
  'nav.chat': { ru: 'Чат', az: 'Söhbət', tr: 'Sohbet' },
  'nav.profile': { ru: 'Профиль', az: 'Profil', tr: 'Profil' },
  'nav.settings': { ru: 'Настройки', az: 'Ayarlar', tr: 'Ayarlar' },

  // Home Screen
  'home.title': { ru: 'Шахматная Платформа AZTR', az: 'AZTR Şahmat Platforması', tr: 'AZTR Satranç Platformu' },
  'home.subtitle': {
    ru: 'Премиальная шахматная платформа для Азербайджана, Турции и России. Общайтесь, соревнуйтесь и настраивайте свой опыт.',
    az: 'Azərbaycan, Türkiyə və Rusiya üçün premium onlayn şahmat ünvanı. Bağlan, yarış və təcrübəni fərdiləşdir.',
    tr: 'Azerbaycan, Türkiye ve Rusya için premium çevrimiçi satranç adresi. Bağlan, rekabet et ve deneyimini özelleştir.'
  },
  'home.playNow': { ru: 'Играть сейчас', az: 'İndi Oyna', tr: 'Şimdi Oyna' },
  'home.cards.play.title': { ru: 'Начать матч', az: 'Matç Oyna', tr: 'Maç Oyna' },
  'home.cards.play.desc': { ru: 'Найдите противника в Bullet, Blitz или Rapid.', az: 'Bullet, Blitz və ya Rapid rejimində rəqib tap.', tr: 'Bullet, Blitz veya Rapid modunda rakip bul.' },
  'home.cards.game.title': { ru: 'Активная игра', az: 'Aktiv Oyun', tr: 'Aktif Oyun' },
  'home.cards.game.desc': { ru: 'Вернитесь к своим текущим матчам или анализу.', az: 'Cari matçlarına və ya analizə qayıt.', tr: 'Mevcut maçlarına veya analize dön.' },
  'home.cards.profile.title': { ru: 'Рейтинг', az: 'Reytinq', tr: 'Sıralama' },
  'home.cards.profile.desc': { ru: 'Проверьте свой рейтинг и положение в стране.', az: 'Reytinqini və ölkə üzrə mövqeyini yoxla.', tr: 'Reytingini ve ülke sıralamanı kontrol et.' },
  'home.cards.chat.title': { ru: 'Сообщество', az: 'İcma', tr: 'Topluluk' },
  'home.cards.chat.desc': { ru: 'Присоединяйтесь к глобальному чату и заводите друзей.', az: 'Qlobal söhbətə qoşul və dostlar tap.', tr: 'Küresel sohbete katıl ve arkadaşlar edin.' },

  // Play Screen
  'play.tabs.play': { ru: 'Играть', az: 'Oyna', tr: 'Oyna' },
  'play.tabs.tournaments': { ru: 'Турниры', az: 'Turnirlər', tr: 'Turnuvalar' },
  'play.tabs.computer': { ru: 'Компьютер', az: 'Kompüter', tr: 'Bilgisayar' },
  'play.timeControl': { ru: 'Контроль времени', az: 'Vaxt Nəzarəti', tr: 'Zaman Kontrolü' },
  'play.matchType': { ru: 'Тип матча', az: 'Matç Növü', tr: 'Maç Türü' },
  'play.type.rated': { ru: 'Рейтинговый', az: 'Reytinqli', tr: 'Dereceli' },
  'play.type.casual': { ru: 'Товарищеский', az: 'Dostluq', tr: 'Dostluk' },
  'play.region': { ru: 'Регион', az: 'Region', tr: 'Bölge' },
  'play.region.global': { ru: 'Глобальный', az: 'Qlobal', tr: 'Küresel' },
  'play.startGame': { ru: 'НАЧАТЬ ИГРУ', az: 'OYUNA BAŞLA', tr: 'OYUNA BAŞLA' },
  'play.playersOnline': { ru: 'Игроков онлайн', az: 'Oyunçu Onlayn', tr: 'Oyuncu Çevrimiçi' },
  'play.searching': { ru: 'Поиск противника...', az: 'Rəqib axtarılır...', tr: 'Rakip aranıyor...' },
  'play.searchingDesc': { ru: 'Ожидание: < 10сек', az: 'Gözlənilən vaxt: < 10s', tr: 'Tahmini bekleme: < 10s' },
  'play.cancel': { ru: 'Отмена', az: 'Ləğv et', tr: 'İptal' },
  'play.friend': { ru: 'Играть с другом', az: 'Dostla Oyna', tr: 'Arkadaşla Oyna' },
  'play.tournaments': { ru: 'Присоединиться к турниру', az: 'Turnirə Qoşul', tr: 'Turnuvaya Katıl' },

  // Game Screen
  'game.tabs.moves': { ru: 'Ходы', az: 'Gedişlər', tr: 'Hamleler' },
  'game.tabs.chat': { ru: 'Чат', az: 'Söhbət', tr: 'Sohbet' },
  'game.tabs.coach': { ru: 'Тренер', az: 'Məşqçi', tr: 'Antrenör' },
  'game.chat.start': { ru: 'Матч начался! Удачи.', az: 'Matç başlayır! Uğurlar.', tr: 'Maç başlıyor! Bol şans.' },
  'game.chat.placeholder': { ru: 'Введите сообщение...', az: 'Mesaj yaz...', tr: 'Mesaj yaz...' },
  'game.resign': { ru: 'Сдаться', az: 'Təslim ol', tr: 'Terk Et' },
  'game.draw': { ru: 'Предложить ничью', az: 'Heç-heçə təklif et', tr: 'Beraberlik Teklif Et' },
  'game.white': { ru: 'Белые', az: 'Ağ', tr: 'Beyaz' },
  'game.black': { ru: 'Черные', az: 'Qara', tr: 'Siyah' },

  // AI Coach UI
  'game.coach.explainPos': { ru: 'Объяснить позицию', az: 'Mövqeyi İzah Et', tr: 'Konumu Açıkla' },
  'game.coach.improve': { ru: 'Что улучшить?', az: 'Nəyi Təkmilləşdirməli?', tr: 'Nasıl Geliştirmeli?' },
  'game.coach.mainIdea': { ru: 'Основная идея', az: 'Əsas İdeya', tr: 'Ana Fikir' },
  'game.coach.openingMistakes': { ru: 'Ошибки в дебюте', az: 'Debüt Səhvləri', tr: 'Açılış Hataları' },
  'game.coach.whyLose': { ru: 'Почему я проиграл?', az: 'Niyə Uduzdum?', tr: 'Neden Kaybettim?' },
  'game.coach.posOrTac': { ru: 'Позиция или тактика?', az: 'Mövqe yoxsa Taktika?', tr: 'Konumsal mı Taktik mi?' },
  'game.coach.attOrDef': { ru: 'Атака или защита?', az: 'Hücum yoxsa Müdafiə?', tr: 'Saldırı mı Savunma mı?' },
  'game.coach.mainLesson': { ru: 'Главный урок', az: 'Əsas Dərs', tr: 'Ana Ders' },
  'game.coach.disclaimer': { ru: 'Обучающие рекомендации на основе общих принципов.', az: 'Ümumi prinsiplərə əsaslanan təhsil rəhbərliyi.', tr: 'Genel ilkelere dayalı eğitim rehberliği.' },
  'game.coach.feedback.title': { ru: 'Отзыв тренера', az: 'Məşqçi Rəyi', tr: 'Antrenör Geri Bildirimi' },
  'game.coach.feedback.type': { ru: 'Тип проблемы', az: 'Problem Növü', tr: 'Sorun Türü' },
  'game.coach.feedback.reason': { ru: 'Основная причина', az: 'Əsas Səbəb', tr: 'Ana Sebep' },
  'game.coach.feedback.better': { ru: 'Лучший подход', az: 'Daha Yaxşı Yanaşma', tr: 'Daha İyi Yaklaşım' },
  'game.coach.feedback.lesson': { ru: 'Главный урок', az: 'Əsas Dərs', tr: 'Ana Ders' },
  'game.coach.feedback.next': { ru: 'Следующая тренировка', az: 'Növbəti Təlim', tr: 'Sıradaki Eğitim' },
  'game.coach.thinking': { ru: 'Думает...', az: 'Düşünür...', tr: 'Düşünüyor...' },

  // Stockfish Analysis UI
  'game.tabs.analysis': { ru: 'Анализ', az: 'Analiz', tr: 'Analiz' },
  'game.analysis.engineLoading': { ru: 'Загрузка движка...', az: 'Mühərrik Yüklənir...', tr: 'Motor Yükleniyor...' },
  'game.analysis.bestMove': { ru: 'Лучший ход', az: 'Ən Yaxşı Gediş', tr: 'En İyi Hamle' },
  'game.analysis.candidates': { ru: 'Кандидаты', az: 'Namizəd Gedişlər', tr: 'Aday Hamleler' },
  'game.analysis.depth': { ru: 'Глубина', az: 'Dərinlik', tr: 'Derinlik' },
  'game.analysis.toggle': { ru: 'Включить анализ', az: 'Analizi Aktivləşdir', tr: 'Analizi Aç/Kapat' },
  'game.analysis.quality.best': { ru: 'Лучший', az: 'Əla', tr: 'En İyi' },
  'game.analysis.quality.good': { ru: 'Хороший', az: 'Yaxşı', tr: 'İyi' },
  'game.analysis.quality.inaccurate': { ru: 'Неточный', az: 'Qeyri-dəqiq', tr: 'Hatalı' },
  'game.analysis.quality.mistake': { ru: 'Ошибка', az: 'Səhv', tr: 'Yanlıш' },
  'game.analysis.quality.blunder': { ru: 'Зевок', az: 'Kobud Səhv', tr: 'Pot' },
  'game.analysis.detail': { ru: 'Детали оценки', az: 'Qiymətləndirmə detalları', tr: 'Değerlendirme detayları' },
  'game.analysis.qualityLabel': { ru: 'Оценка качества', az: 'Keyfiyyətin qiymətləndirilməsi', tr: 'Kalite değerlendirmesi' },
  'game.analysis.nomoves': { ru: 'Ходов еще нет', az: 'Hələ gediş yoxdur', tr: 'Henüz hamle yok' },
  'game.analysis.unavailable': { ru: 'Анализ недоступен', az: 'Analiz mümkün deyil', tr: 'Analiz kullanılamıyor' },
  'game.analysis.hint': { ru: 'Используйте линии движка вместе с советами тренера.', az: 'Məşqçinin məsləhətləri ilə birlikdə mühərrik xətlərindən istifadə edin.', tr: 'Antrenör tavsiyeleriyle birlikte motor hatlarını kullanın.' },

  // AI Chat Assistant UI
  'chat.assistant.title': { ru: 'Чат-помощник ИИ', az: 'Söhbət Köməkçisi', tr: 'Sohbet Yardımcısı' },
  'chat.assistant.translate': { ru: 'Перевести', az: 'Tərcümə Et', tr: 'Çevir' },
  'chat.assistant.translateBubble': { ru: 'Перевести на мой язык', az: 'Dilimə tərcümə et', tr: 'Dilime çevir' },
  'chat.assistant.polite': { ru: 'Вежливо', az: 'Nəzakətli Et', tr: 'Nazik Yap' },
  'chat.assistant.friendly': { ru: 'Дружелюбно', az: 'Səmimi Et', tr: 'Samimi Yap' },
  'chat.assistant.neutral': { ru: 'Нейтрально', az: 'Neytral Et', tr: 'Nötr Yap' },
  'chat.assistant.toxicityWarning': { ru: 'Предупреждение: это звучит агрессивно. Попробуйте спокойнее?', az: 'Təhlükəsizlik Xəbərdarlığı: Bu bir az aqressiv görünür. Daha sakit versiyanı sınayın?', tr: 'Güvenlik Uyarısı: Bu biraz agresif görünüyor. Daha sakin bir sürüm dener misiniz?' },
  'chat.assistant.phrases': { ru: 'Быстрые фразы', az: 'Tez Chess İfadələri', tr: 'Hızlı Satranç Иfadeleri' },
  'chat.assistant.terms': { ru: 'Термины', az: 'Şahmat Termini İzahları', tr: 'Satranç Terimi Açıklamaları' },
  'chat.assistant.suggestions': { ru: 'Быстрые ответы', az: 'Sürətli Cavablar', tr: 'Hızlı Cevaplar' },
  'chat.assistant.preview': { ru: 'Предпросмотр ИИ', az: 'Süni İntellekt Təklifi', tr: 'Yapay Zeka Önerisi' },
  'chat.assistant.insert': { ru: 'Вставить', az: 'Mətnə Əlavə Et', tr: 'Metne Ekle' },
  'chat.assistant.close': { ru: 'Закрыть помощника', az: 'Köməkçini Bağla', tr: 'Yardımcıyı Kapat' },

  // Chat Screen
  'chat.globalTitle': { ru: 'Глобальный чат', az: 'Qlobal Region Söhbəti', tr: 'Küresel Bölge Sohbeti' },
  'chat.subtitle': { ru: 'Азербайджан • Турция • Россия', az: 'Azərbaycan • Türkiyə • Rusiya', tr: 'Azerbaycan • Türkiye • Rusya' },
  'chat.onlineUsers': { ru: 'Пользователи онлайн', az: 'Onlayn İstifadəçilər', tr: 'Çevrimiçi Kullanıcılar' },
  'chat.sendPlaceholder': { ru: 'Отправить сообщение в глобальный чат...', az: 'Qlobal söhbətə mesaj göndər...', tr: 'Küresel sohbete mesaj gönder...' },

  // Profile Screen
  'profile.memberSince': { ru: 'В сообществе с', az: 'Üzvlük tarixi', tr: 'Üyelik tarihi' },
  'profile.performance': { ru: 'Результативность', az: 'Göstəricilər', tr: 'Performans' },
  'profile.wins': { ru: 'Победы', az: 'Qələbə', tr: 'Galibiyet' },
  'profile.draws': { ru: 'Ничьи', az: 'Heç-heçə', tr: 'Beraberlik' },
  'profile.losses': { ru: 'Поражения', az: 'Məğlubiyyət', tr: 'Mağlubiyet' },
  'profile.recentTrophies': { ru: 'Трофеи', az: 'Son Nailiyyətlər', tr: 'Son Başarılar' },
  'profile.recentGames': { ru: 'Последние игры', az: 'Son Oyunlar', tr: 'Son Oyunlar' },
  'profile.review': { ru: 'Обзор →', az: 'Baxış →', tr: 'İncele →' },

  // Settings Screen
  'settings.title': { ru: 'Настройки приложения', az: 'Tətbiq Ayarları', tr: 'Uygulama Ayarları' },
  'settings.changeLanguage': { ru: 'Изменить язык', az: 'Dili dəyişdir', tr: 'Dili değiştir' },
  'settings.specialThemes': { ru: 'Специальные темы', az: 'Xüsusi Mövzuları Aktivləşdir', tr: 'Özel Temaları Etkinleştir' },
  'settings.boardAppearance': { ru: 'Внешний вид доски', az: 'Lövhə Görünüşü', tr: 'Tahta Görünümü' },
  'settings.pieceStyles': { ru: 'Шахматные фигуры', az: 'Şahmat Fiqurları', tr: 'Satranç Taşları' },
  'settings.soundThemes': { ru: 'Звуковые темы', az: 'Səs Mövzuları', tr: 'Ses Temaları' },

  // Role Separation & Categories
  'game.coach.category.strategy': { ru: 'Стратегия и Принципы', az: 'Strateji və Prinsiplər', tr: 'Strateji ve İlkeler' },
  'game.coach.category.opening': { ru: 'Дебютная подготовка', az: 'Debüt hazırlığı', tr: 'Açılış hazırlığı' },
  'game.coach.category.review': { ru: 'Общий обзор', az: 'Ümumi baxış', tr: 'Genel bakış' },
  'game.coach.status.ready': { ru: 'Тренер готов к консультации', az: 'Məşqçi məsləhət üçün hazırdır', tr: 'Antrenör danışmanlık için hazır' },
  'game.analysis.dashboard': { ru: 'Панель инструментов движка', az: 'Mühərrik alətlər paneli', tr: 'Motor araç paneli' },
  'game.analysis.variations': { ru: 'Тактические варианты', az: 'Taktiki variantlar', tr: 'Taktik varyasyonlar' },
  'game.analysis.engineStatus': { ru: 'Статус движка', az: 'Mühərrik statusu', tr: 'Motor durumu' }
};
